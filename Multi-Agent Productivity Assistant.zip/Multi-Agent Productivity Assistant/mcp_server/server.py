import json
import os
import pickle
from datetime import datetime, timedelta

from mcp.server.fastmcp import FastMCP
from googleapiclient.discovery import build

mcp = FastMCP("productivity_mcp")

DB_FILE = "data.json"
TOKEN_FILE = "token.pickle"


def _load():
    if not os.path.exists(DB_FILE):
        return {
            "tasks": [],
            "events": [],
            "notes": [],
            "workflow_runs": []
        }
    with open(DB_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def _save(data):
    with open(DB_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def _get_calendar_service():
    with open(TOKEN_FILE, "rb") as token:
        creds = pickle.load(token)
    return build("calendar", "v3", credentials=creds)


def _parse_datetime(date_str: str, time_str: str):
    now = datetime.now()

    if not date_str or date_str.lower() == "today":
        base_date = now.date()
    elif date_str.lower() == "tomorrow":
        base_date = (now + timedelta(days=1)).date()
    else:
        base_date = datetime.strptime(date_str, "%Y-%m-%d").date()

    if not time_str:
        event_time = datetime.strptime("09:00", "%H:%M").time()
    else:
        cleaned = time_str.strip().upper().replace(".", "")
        for fmt in ("%I %p", "%I:%M %p", "%H:%M"):
            try:
                event_time = datetime.strptime(cleaned, fmt).time()
                break
            except ValueError:
                event_time = None
        if event_time is None:
            raise ValueError("Unsupported time format. Use like '5 PM' or '17:00'.")

    start_dt = datetime.combine(base_date, event_time)
    end_dt = start_dt + timedelta(hours=1)
    return start_dt, end_dt


@mcp.tool()
def create_task(title: str, due_date: str = "", priority: str = "medium") -> dict:
    """Create a task."""
    data = _load()
    task = {
        "id": len(data["tasks"]) + 1,
        "title": title,
        "due_date": due_date,
        "priority": priority,
        "status": "pending",
        "created_at": datetime.utcnow().isoformat()
    }
    data["tasks"].append(task)
    _save(data)
    return task


@mcp.tool()
def list_tasks() -> list:
    """List all tasks."""
    return _load()["tasks"]


@mcp.tool()
def create_event(title: str, date: str = "", time: str = "", attendees: str = "") -> dict:
    """Create a real Google Calendar event with a 15-minute reminder."""
    service = _get_calendar_service()
    start_dt, end_dt = _parse_datetime(date, time)

    attendee_list = []
    if attendees:
        for item in attendees.split(","):
            value = item.strip()
            if value and "@" in value:
                attendee_list.append({"email": value})

    event_body = {
        "summary": title,
        "start": {
            "dateTime": start_dt.isoformat(),
            "timeZone": "Asia/Kolkata",
        },
        "end": {
            "dateTime": end_dt.isoformat(),
            "timeZone": "Asia/Kolkata",
        },
        "reminders": {
            "useDefault": False,
            "overrides": [
                {"method": "popup", "minutes": 15}
            ],
        },
    }

    if attendee_list:
        event_body["attendees"] = attendee_list

    created_event = service.events().insert(calendarId="primary", body=event_body).execute()

    data = _load()
    local_event = {
        "id": len(data["events"]) + 1,
        "title": title,
        "date": date,
        "time": time,
        "attendees": attendees,
        "google_event_id": created_event.get("id"),
        "google_event_link": created_event.get("htmlLink"),
        "created_at": datetime.utcnow().isoformat()
    }
    data["events"].append(local_event)
    _save(data)

    return {
        "message": "Google Calendar event created successfully",
        "title": title,
        "start": start_dt.isoformat(),
        "end": end_dt.isoformat(),
        "event_link": created_event.get("htmlLink"),
    }


@mcp.tool()
def list_events() -> list:
    """List all events saved by the assistant."""
    return _load()["events"]


@mcp.tool()
def save_note(title: str, content: str) -> dict:
    """Save a note."""
    data = _load()
    note = {
        "id": len(data["notes"]) + 1,
        "title": title,
        "content": content,
        "created_at": datetime.utcnow().isoformat()
    }
    data["notes"].append(note)
    _save(data)
    return note


@mcp.tool()
def list_notes() -> list:
    """List all notes."""
    return _load()["notes"]


if __name__ == "__main__":
    mcp.run()