from google.adk.agents import Agent
from google.adk.tools.mcp_tool import McpToolset
from google.adk.tools.mcp_tool.mcp_session_manager import StdioConnectionParams
from mcp import StdioServerParameters

mcp_toolset = McpToolset(
    connection_params=StdioConnectionParams(
        server_params=StdioServerParameters(
            command="python",
            args=["mcp_server/server.py"],
        ),
    ),
)

task_agent = Agent(
    name="task_agent",
    model="gemini-2.5-flash-lite",
    description="Handles task creation and task listing via MCP tools.",
    instruction="""
You are a task management agent.

Use MCP tools for task-related actions.
If the user asks to create a task, use the MCP task creation tool.
If the user asks to list tasks, use the MCP task listing tool.
Do not ask unnecessary follow-up questions.
""",
    tools=[mcp_toolset],
)

calendar_agent = Agent(
    name="calendar_agent",
    model="gemini-2.5-flash-lite",
    description="Handles event and schedule management via MCP tools.",
    instruction="""
You are a calendar management agent.

Use MCP tools for event-related actions.
If the user asks to schedule/create/book an event or meeting, use the MCP event creation tool.
If the user asks to list events, use the MCP event listing tool.
Do not say you cannot schedule meetings if the MCP tool is available.
""",
    tools=[mcp_toolset],
)

notes_agent = Agent(
    name="notes_agent",
    model="gemini-2.5-flash-lite",
    description="Handles notes via MCP tools.",
    instruction="""
You are a notes management agent.

Use MCP tools for note-related actions.
If the user asks to save a note, use the MCP note tool.
If the user asks to list notes, use the MCP note listing tool.
Do not ask unnecessary follow-up questions.
""",
    tools=[mcp_toolset],
)

root_agent = Agent(
    name="root_agent",
    model="gemini-2.5-flash-lite",
    description="Main coordinator agent.",
    instruction="""
You are the main coordinator agent in a multi-agent productivity assistant.

Your job:
- Understand the user's request
- Break it into steps
- Delegate each step to the correct sub-agent
- Execute workflows using MCP tools
- Return a clear, human-friendly final response

IMPORTANT:
- Always summarize what was done
- Do NOT return raw tool output
- Convert results into simple user-friendly sentences

Examples:

User: "Create a task called Prepare demo"
Response: "Task 'Prepare demo' has been created successfully."

User: "Schedule a meeting tomorrow at 5 PM and create a task"
Response:
"Meeting scheduled for tomorrow at 5 PM.
Task 'Prepare for meeting' created successfully."

Always combine results into one clean response.
""",
    sub_agents=[task_agent, calendar_agent, notes_agent],
)