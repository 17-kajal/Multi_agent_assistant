import json
import os
from datetime import datetime

DB_FILE = "data.json"


def _load():
    if not os.path.exists(DB_FILE):
        return {
            "tasks": [],
            "events": [],
            "notes": [],
            "workflow_runs": []
        }
    with open(DB_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def _save(data):
    with open(DB_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


# ---------------- TASKS ----------------

def add_task(title, due_date="", priority="medium"):
    data = _load()
    task = {
        "id": len(data["tasks"]) + 1,
        "title": title,
        "due_date": due_date,
        "priority": priority,
        "status": "pending",
        "created_at": datetime.utcnow().isoformat()
    }
    data["tasks"].append(task)
    _save(data)
    return task


def list_tasks():
    return _load()["tasks"]


# ---------------- EVENTS ----------------

def add_event(title, date="", time="", attendees=""):
    data = _load()
    event = {
        "id": len(data["events"]) + 1,
        "title": title,
        "date": date,
        "time": time,
        "attendees": attendees,
        "created_at": datetime.utcnow().isoformat()
    }
    data["events"].append(event)
    _save(data)
    return event


def list_events():
    return _load()["events"]


# ---------------- NOTES ----------------

def add_note(title, content):
    data = _load()
    note = {
        "id": len(data["notes"]) + 1,
        "title": title,
        "content": content,
        "created_at": datetime.utcnow().isoformat()
    }
    data["notes"].append(note)
    _save(data)
    return note


def list_notes():
    return _load()["notes"]


# ---------------- WORKFLOW LOG ----------------

def log_workflow(user_request, result):
    data = _load()
    run = {
        "id": len(data["workflow_runs"]) + 1,
        "user_request": user_request,
        "result": result,
        "created_at": datetime.utcnow().isoformat()
    }
    data["workflow_runs"].append(run)
    _save(data)
    return run