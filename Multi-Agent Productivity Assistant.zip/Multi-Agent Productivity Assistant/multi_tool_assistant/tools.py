from .db import add_task, list_tasks, add_event, list_events, add_note, list_notes


def create_task_tool(title: str, due_date: str = "", priority: str = "medium") -> dict:
    """
    Create a task for the user.
    """
    return add_task(title=title, due_date=due_date, priority=priority)


def list_tasks_tool() -> list:
    """
    Return all tasks.
    """
    return list_tasks()


def create_event_tool(title: str, date: str = "", time: str = "", attendees: str = "") -> dict:
    """
    Create a calendar event for the user.
    """
    return add_event(title=title, date=date, time=time, attendees=attendees)


def list_events_tool() -> list:
    """
    Return all calendar events.
    """
    return list_events()


def save_note_tool(title: str, content: str) -> dict:
    """
    Save a note for the user.
    """
    return add_note(title=title, content=content)


def list_notes_tool() -> list:
    """
    Return all notes.
    """
    return list_notes()